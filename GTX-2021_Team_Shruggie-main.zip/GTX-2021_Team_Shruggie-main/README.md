# GTX-2021_Team_Shruggie
Code repository for GTX 2021 for Team Shruggie 
There are six code notebooks for the project.
Merging datasets_EagleBine and Merging datasets_Duvernay files explain the dataset merging workflow for both the basin respectively. 
Basic EDA and spatial mapping shows intial data exploration vizualization and spatial mapping for EagleBine and Duvrnay basins. 
Machine learning modelling_NN notebook compiles code for Neural network modelling for EagleBine and Duvernay data sets and perform the final predictions for submissions. 
Import_LAS notebook consist of exporting the well LAS files and aggregating the different log values for each UWI along with nearest depth where BHT is recorded. Further it has been merged to combined dataframes of both basins.
Explainibility_mapping file identify feature impact using several methods and visualize temperature by spatial mapping.
